import tweepy
import csv
import pandas as pd
import os
import mysql.connector

import wget

consumer_key = "3WOMWVUWynf5J96hRqSaZyU1G"
consumer_secret = "uKQ6fhflRk2GkosXydVHDDvJHw8z6AhjZiIKmn31dyFQKpp3OA"
access_token = "1590583203386994689-YRVFyrRqyEzjUuCtSGmB9L8wLbXjcP"
access_token_secret = "2cQHqlLZmtIeoc7H1fv42eKXyfgYvczlmKD7vp7jhuCmb"

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth,wait_on_rate_limit=True)

tweets = []


def username_tweets_to_csv(username, count):
    try:
        # Creation of query method using parameters
        tweets = tweepy.Cursor(api.user_timeline, id=username).items(count)

        # Pulling information from tweets iterable object
        tweets_list = [[tweet.user.name, tweet.id_str, tweet.created_at , tweet.source, tweet.text] for tweet in tweets]

        # Creation of dataframe from tweets list
        # Add or remove columns as you remove tweet information
        tweets_df = pd.DataFrame(tweets_list, columns=['User', 'Tweet Id', 'Datetime', 'Source of Tweet', 'Text'])

        # Converting dataframe to CSV
        tweets_df.to_csv('{}-tweets.csv'.format(username), sep=',', index=False)

    except BaseException as e:
        print('failed on_status,', str(e))
        time.sleep(3)


# Input username to scrape tweets and name csv file
# Max recent tweets pulls x amount of most recent tweets from that user
username = 'NWSBoston'
count = 150

# Calling function to turn username's past X amount of tweets into a CSV file
username_tweets_to_csv(username, count)

# Input username to scrape tweets and name csv file
# Max recent tweets pulls x amount of most recent tweets from that user
username = 'NWSSanAntonio'
count = 150

# Calling function to turn username's past X amount of tweets into a CSV file
username_tweets_to_csv(username, count)

# Input username to scrape tweets and name csv file
# Max recent tweets pulls x amount of most recent tweets from that user
username = 'NWSSanDiego'
count = 150

# Calling function to turn username's past X amount of tweets into a CSV file
username_tweets_to_csv(username, count)

# Input username to scrape tweets and name csv file
# Max recent tweets pulls x amount of most recent tweets from that user
username = 'NWSBismarck'
count = 150

# Calling function to turn username's past X amount of tweets into a CSV file
username_tweets_to_csv(username, count)

#rom pandas.core.groupby.groupby import F
SanDiegoData = pd.read_csv("NWSSanDiego-tweets.csv")
# print(data)
# print(data1)
#print(data.size)
# rows=len(data.axes[0])
# print(rows)
a = []
flag = False

for row in SanDiegoData['Text']:
    for word in row.split():
     if word == "cold":
       a.append(word)
       flag=False
       break
     elif word == "rain":
       a.append(word)
       flag=False
       break
     elif word == "snow":
       a.append(word)
       flag=False
       break
     elif word == "wind":
       a.append(word)
       flag=False
       break
     elif word == "warm":
       a.append(word)
       flag=False
       break
     else:
         flag = True
    if flag == True:
        a.append("neutral")


SanDiegoData['Climate Category'] = a
print(SanDiegoData)
SanDiegoData.to_csv('ModifiedNWSSanDiego-tweets.csv')
# #data.to_csv('ModifiedNWSSanDiego-tweets.csv')

DmddAss2= mysql.connector.connect(host='localhost', user='root', passwd='root@123', database='weather')
mycursor = DmddAss2.cursor()

for i,row in SanDiegoData.iterrows():
    sql = "INSERT INTO weather.nws_sandiego values(%s,%s,%s,%s,%s,%s)"
    mycursor.execute(sql,tuple(row))
    DmddAss2.commit()






#from pandas.core.groupby.groupby import F
BostonData = pd.read_csv("NWSBoston-tweets.csv")
# print(data)
# print(data1)
#print(data.size)
# rows=len(data.axes[0])
# print(rows)
b = []
flag = False

for row in BostonData['Text']:
    for word in row.split():
     if word == "cold":
       b.append(word)
       flag=False
       break
     elif word == "rain":
       b.append(word)
       flag=False
       break
     elif word == "snow":
       b.append(word)
       flag=False
       break
     elif word == "wind":
       b.append(word)
       flag=False
       break
     elif word == "warm":
       b.append(word)
       flag=False
       break
     else:
         flag = True
    if flag == True:
        b.append("neutral")


BostonData['Climate Category'] = b
print(BostonData)
BostonData.to_csv('ModifiedNWSBoston-tweets.csv')
# #data.to_csv('ModifiedNWSSanDiego-tweets.csv')

DmddAss2= mysql.connector.connect(host='localhost', user='root', passwd='root@123', database='weather')
mycursor = DmddAss2.cursor()

for i,row in BostonData.iterrows():
    sql = "INSERT INTO weather.nws_boston values(%s,%s,%s,%s,%s,%s)"
    mycursor.execute(sql,tuple(row))
    DmddAss2.commit()



#from pandas.core.groupby.groupby import F
BismarckData = pd.read_csv("NWSBismarck-tweets.csv")
# print(data)
# print(data1)
#print(data.size)
# rows=len(data.axes[0])
# print(rows)
c = []
flag = False

for row in BismarckData['Text']:
    for word in row.split():
     if word == "cold":
       c.append(word)
       flag=False
       break
     elif word == "rain":
       c.append(word)
       flag=False
       break
     elif word == "snow":
       c.append(word)
       flag=False
       break
     elif word == "wind":
       c.append(word)
       flag=False
       break
     elif word == "warm":
       c.append(word)
       flag=False
       break
     else:
         flag = True
    if flag == True:
        c.append("neutral")


BismarckData['Climate Category'] = c
print(BismarckData)
BismarckData.to_csv('ModifiedNWSBismarck-tweets.csv')
# #data.to_csv('ModifiedNWSSanDiego-tweets.csv')

DmddAss2= mysql.connector.connect(host='localhost', user='root', passwd='root@123', database='weather')
mycursor = DmddAss2.cursor()

for i,row in BismarckData.iterrows():
    sql = "INSERT INTO weather.nws_bismarck values(%s,%s,%s,%s,%s,%s)"
    mycursor.execute(sql,tuple(row))
    DmddAss2.commit()


#from pandas.core.groupby.groupby import F
SanAntonioData = pd.read_csv("NWSSanAntonio-tweets.csv")
# print(data)
# print(data1)
#print(data.size)
# rows=len(data.axes[0])
# print(rows)
d = []
flag = False

for row in SanAntonioData['Text']:
    for word in row.split():
     if word == "cold":
       d.append(word)
       flag=False
       break
     elif word == "rain":
       d.append(word)
       flag=False
       break
     elif word == "snow":
       d.append(word)
       flag=False
       break
     elif word == "wind":
       d.append(word)
       flag=False
       break
     elif word == "warm":
       d.append(word)
       flag=False
       break
     else:
         flag = True
    if flag == True:
        d.append("neutral")


SanAntonioData['Climate Category'] = d
print(SanAntonioData)
SanAntonioData.to_csv('ModifiedNWSSanAntonio-tweets.csv')
# #data.to_csv('ModifiedNWSSanDiego-tweets.csv')


DmddAss2= mysql.connector.connect(host='localhost', user='root', passwd='root@123', database='weather')
mycursor = DmddAss2.cursor()

for i,row in SanAntonioData.iterrows():
    sql = "INSERT INTO weather.nws_sanantonio values(%s,%s,%s,%s,%s,%s)"
    mycursor.execute(sql,tuple(row))
    DmddAss2.commit()





